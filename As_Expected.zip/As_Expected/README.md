

![Logo](https://www.linkpicture.com/q/logo_581.png)
# As Expected

The genre of the game is adventure and mind game.Its a platformer game made with the help of pygame module.
The character of the game is someone who loves lava which is basically backstory of the game.
## Installation

Install my game either by

```bash
  install pygame module in any code editor
  run code file named As_Expected.
```
or by just clicking exe file
```bash
  As_Expected.exe file or application file
```
    
## How to Play

Right arrow - To move Right

Left arrow - To move Left

Space - To Jump



## FAQ

#### Question 1 - Where is game location?

Answer 1 - Game is in dist file of main folder


#### Question 2 - How to open exe file if windows defender stops you?

Answer 2 - Right click on exe file->open properties->click unblock at the end->Apply.

#### Question 3 - Is there any need of code editor to play game?

Answer 3 - No need to use any compiler directly open exe file from 'dist' file.


## License

License for code will be the same as the pygame license.

License for background is with a content creator on youtube channel name 'MAITTRE'.

Many assets are self created and other are free to use open source.
Background Image is created by an designer TREKE whose permission is taken as this project is non-commercial use.


## Screenshots

![App Screenshot](https://www.linkpicture.com/q/hhhhhh_2.png)


## Appendix

[Youtube link for music](https://www.youtube.com/watch?v=0Zo7xT602Fo)

[Instagram of background image creater](https://www.instagram.com/p/CYUDCvjsymh/?utm_source=ig_web_copy_link)

